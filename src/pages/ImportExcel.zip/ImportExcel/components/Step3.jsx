import { Typography } from "@mui/material";
import React from "react";

const Step3 = () => {
  return (
    <>
      <Typography variant="h6">INSTRUCTIONS:</Typography>
      <p>This is a Preview of the data that will imported</p>
    </>
  );
};

export default Step3;
